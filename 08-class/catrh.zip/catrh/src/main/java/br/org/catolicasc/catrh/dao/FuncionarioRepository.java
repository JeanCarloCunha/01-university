package br.org.catolicasc.catrh.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import br.org.catolicasc.catrh.bean.Funcionario;

@Repository	
public interface FuncionarioRepository 
	extends CrudRepository<Funcionario, Long>, 
	PagingAndSortingRepository<Funcionario, 
				Long> {

}
