package br.org.catolicasc.catrh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatrhApplicationTests {

	@Test
	void contextLoads() {
	}

}
