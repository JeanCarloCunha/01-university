package br.org.catolicasc.catrh;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import br.org.catolicasc.catrh.bean.Funcionario;
import br.org.catolicasc.catrh.dao.CargoRepository;
import br.org.catolicasc.catrh.dao.FuncionarioProjecao;
import br.org.catolicasc.catrh.dao.FuncionarioRepository;

@SpringBootTest
class FuncionarioTest {

	@Autowired
	private FuncionarioRepository funcionarioRepository;
	
	@Autowired
	private CargoRepository cargoRepository;
	
	//@Test
	public void testSave() {
		
		Funcionario f1 = new Funcionario();
		f1.setNome("João Smith");
		f1.setCargo(cargoRepository.findById(1L).get());
		f1.setSalario(10000d);
		
		Funcionario f2 = new Funcionario();
		f2.setNome("Maria Doe");
		f2.setCargo(cargoRepository.findById(2L).get());
		f2.setSalario(20000d);
		
		funcionarioRepository.save(f1);
		funcionarioRepository.save(f2);
		
		assertNotNull(f1.getId());
		assertNotNull(f2.getId());
	}	
	@Test
	public void testDerived() {
		List<Funcionario> funcionarios = 
				this.funcionarioRepository.findByNome("Maria Doe");
		assertTrue(funcionarios.size() == 1);
	}
	@Test
	public void testJpql() {
		List<Funcionario> res = 
				this.funcionarioRepository
					.pesquisarPeloSalarioMaior(12000.0);
		assertTrue(res.get(0)
					.getNome().equals("Maria Doe"));
	}
	
	@Test
	public void testNativeQuery() {
		List<Funcionario> res = 
				this.funcionarioRepository
					.listarFuncionariosCargo(2l);
		assertTrue(res.get(0)
					.getNome().equals("Maria Doe"));
	}
	
	@Test
	public void testProjecao() {
		List<FuncionarioProjecao> res = 
				this.funcionarioRepository
					.listarFuncionarioNomeSalario();
		assertTrue(res.size() == 2);
		assertTrue(res.get(0).getNome() != null);
	}
	
}
