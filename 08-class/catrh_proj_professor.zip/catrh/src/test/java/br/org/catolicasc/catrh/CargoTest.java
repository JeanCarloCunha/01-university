package br.org.catolicasc.catrh;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import br.org.catolicasc.catrh.bean.Cargo;
import br.org.catolicasc.catrh.dao.CargoRepository;

@SpringBootTest
class CargoTest {

	@Autowired
	private CargoRepository repository;
	
	@Test
	public void testSave() {
		Cargo cargo = new Cargo();
		cargo.setDescricao("Programador de Computador");
		repository.save(cargo);
		assertNotNull(cargo.getId());
	}

}
