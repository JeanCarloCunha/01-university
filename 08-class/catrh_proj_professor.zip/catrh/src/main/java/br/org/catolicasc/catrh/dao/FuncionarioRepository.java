package br.org.catolicasc.catrh.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import br.org.catolicasc.catrh.bean.Funcionario;

@Repository	
public interface FuncionarioRepository 
	extends CrudRepository<Funcionario, Long>, 
	PagingAndSortingRepository<Funcionario, 
				Long> {

	List<Funcionario> findByNome(String nome);
	
	@Query("select f from Funcionario f where f.salario > :salario")
	List<Funcionario> pesquisarPeloSalarioMaior(Double salario);

	@Query(value = "select * from funcionario f where f.cargo_id = :cargoId",
			nativeQuery = true)
	List<Funcionario> listarFuncionariosCargo(Long cargoId);
	
	@Query(value = "select f.id, f.nome, "
			+ "	f.salario from funcionario f ", 
			nativeQuery = true)
	List<FuncionarioProjecao> 
		listarFuncionarioNomeSalario();


}
