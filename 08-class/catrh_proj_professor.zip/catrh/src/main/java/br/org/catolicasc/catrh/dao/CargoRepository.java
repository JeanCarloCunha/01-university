package br.org.catolicasc.catrh.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import br.org.catolicasc.catrh.bean.Cargo;

@Repository
public interface CargoRepository 
	extends CrudRepository<Cargo, Long> {

}
