package br.org.catolicasc.catrh.dao;

public interface FuncionarioProjecao {

	Integer getId();
	String getNome();
	Double getSalario();
}
