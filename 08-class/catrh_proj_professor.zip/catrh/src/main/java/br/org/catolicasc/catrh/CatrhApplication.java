package br.org.catolicasc.catrh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatrhApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(CatrhApplication.class, args);
	}
}
